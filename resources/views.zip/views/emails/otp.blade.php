<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h2>Hello,</h2>
    <p>Your OTP code is: <strong>{{ $otp }}</strong></p>
    <p>This code is valid for 5 minutes.</p>
</body>
</html>
